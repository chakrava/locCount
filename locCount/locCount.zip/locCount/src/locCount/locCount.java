package locCount;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class locCount {
	
	
	public static void main (String args[]) throws IOException
	{
		ArrayList<File> files=new ArrayList<File>();
		File toFile = new File (System.getProperty("user.dir"));
		System.out.println("Starting directory: "+toFile+"\n");
		
		files = findFiles(files,toFile);
		
		BufferedReader in = null;
		
		int locCount=0;
		int totalLocCount=0;
		
		for(File toOpenFile:files){
			try{
				String toOpen = toOpenFile.toString();
				System.out.println("Checking file: "+toOpen);
				locCount=0;
				if(toOpen.matches(".*.java")){
					in = new BufferedReader(new FileReader(toOpen));
					
					String temp;
					while((temp=in.readLine()) !=null){
						temp=temp.replaceAll("\\s","");
						
						if(temp.length()>2 && (
								!temp.substring(0,2).matches("//") ||
								(temp.length()>=6 && !temp.substring(0,6).matches("import") && !temp.substring(0,6).matches("packag")) )){
							locCount++;
							totalLocCount++;
						}
						
					}
				}
			}catch(Error e){
				System.out.println("Someone messed something up\n\n"+e.getMessage());
			}catch(Exception e){
				System.out.println("Someone messed something up\n\n"+e.getMessage());
			}
			
			
			System.out.println("Lines counted: "+locCount);
		}
		
		System.out.println("Total lines counted: "+totalLocCount);
	}
	
	public static ArrayList<File> findFiles(ArrayList<File> list, File toFind){
		ArrayList<File> temp = new ArrayList<>();
		
		temp.addAll(Arrays.asList(toFind.listFiles()));
		
		for(File xFile : temp){
			if(xFile.isDirectory()){
				findFiles(list,xFile);
			}
		}
		list.addAll(temp);
		return list;
	}
}